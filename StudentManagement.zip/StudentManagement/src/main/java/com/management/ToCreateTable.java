/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.management;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ToCreateTable {

//Required Json
//{
//    "rollno":1,
//    "firstname":"Abhishek",
//    "lastname":"Dubey",
//    "gender":"MALE",
//    "contactno":"8850801468;9820744591",
//    "emailid":"abdubey@gmail.com;abhi123@hmail.com",
//    "dob":"2002-11-22",
//    "active":1,
//    "qualificationDetails":[
//        {
//            "institutionname":"Anudip Foundation",
//            "course":"Java FullStack Development using Angular  ",
//            "duration":6,
//            "fromdate":"2023-2-11",
//            "todate":"2023-7-23",
//            "percentage":98
//        }
//    ]
//}
    
    
    
    public static void main(String args[]) {
        String url = "jdbc:mysql://localhost:3306/acs_report_tenant_1";
        final String user = "root";
        final String pass = "ABHI";

        String driver = "";
        Connection conn = null;

        CallableStatement cstmt = null;
        CallableStatement cstmt0 = null;
        CallableStatement cstmt1 = null;
        CallableStatement cstmt2 = null;
        CallableStatement cstmt3 = null;
        String query = null;
        String query0 = null;
        String query1 = null;
        String query3 = null;
        try {
            conn = DriverManager.getConnection(url, user, pass);
            System.out.println("************Connection Done Sucessfully******************");

            query0 = "SHOW TABLES LIKE 'student_information'";
            cstmt0 = conn.prepareCall(query0);
            if (cstmt0.executeQuery().next()) {
                System.out.println("***********'student_information' Table Exists---> Droping the Existing Table*****************");
                String dropQuery = "DROP TABLE student_information";
                cstmt1 = conn.prepareCall(dropQuery);
                cstmt1.executeUpdate();
                System.out.println("***********'student_information' Table Droped Sucessfully*****************");
            }

            query1 = "SHOW TABLES LIKE 'qualification_details'";
            cstmt2 = conn.prepareCall(query1);
            if (cstmt2.executeQuery().next()) {
                System.out.println("***********'qualification_details' Table Exists---> Droping the Existing Table*****************");
                String dropQuery = "DROP TABLE qualification_details";
                cstmt2 = conn.prepareCall(dropQuery);
                cstmt2.executeUpdate();
                System.out.println("***********'qualification_details' Table Droped Sucessfully*****************");
            }

            System.out.println("***********Creating New Table 'student_information'*****************");
            query = "CREATE TABLE student_information( studentid INT PRIMARY KEY AUTO_INCREMENT ,rollno INT ,first_name VARCHAR(255),last_name VARCHAR(255) ,gender VARCHAR(100) , contact_number varchar(200) ,emailid VARCHAR(255),dob VARCHAR(50) ,active BIT , isdelete BIT);";
            cstmt = conn.prepareCall(query);

            System.out.println("*********Query Executed Sucessfully*********>>>>>>>" + cstmt.toString());
            cstmt.executeUpdate();
            System.out.println("*********'student_information'  Table Creation Done Sucessfully**************");

            
            
            System.out.println("***********Creating New Table 'qualification_details'*****************");
            query3 = "CREATE TABLE qualification_details(studentid INT , institution_name VARCHAR(255) , course VARCHAR(255) , duration INT ,fromdate  VARCHAR(50)  ,todate  VARCHAR(50) , percentage INT);";
            cstmt3 = conn.prepareCall(query3);

            System.out.println("*********Query Executed Sucessfully*********>>>>>>>" + cstmt3.toString());
            cstmt3.executeUpdate();
            System.out.println("*********' qualification_details Table Creation Done Sucessfully**************");
            cstmt3.close();
            cstmt1.close();
            cstmt0.close();
        } catch (SQLException e) {
            e.printStackTrace(); // This will print the exception stack trace
        } finally {
            cstmt = null;
            conn = null;
            query = null;
        }

    }
}
